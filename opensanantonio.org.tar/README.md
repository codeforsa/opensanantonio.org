http://codeforhamptonroads.org
===================

Landing page for *Code for Hampton Roads*

Note that branch `gh-pages` is what shows on production codeforhamptonroads.org. Master does nothing.

#How to Code for this Repo
Option A: Fork, Edit, then Pull Request when ready.
Option B: If in the Hampton Road's Brigade and you have write access to repo: Develop/test in your own branch, preferablly a feature-named-branch, and once it's ready for production, merge into gh-pages, which auto deploys to GitHub pages for codeforhamptonroads.org

Also, it's nice if you merge/commit to gh-pages, that you [let the team know on our Google Group](https://groups.google.com/a/codeforamerica.org/forum/#!forum/c4hrva). 

#License
[Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0)

#Attribution and Thanks
This repo and the site codeforvirginiabeach.org uses Twitter Bootstrap and started from their [Carousel jumbotron](http://twitter.github.com/bootstrap/examples/carousel.html) template. They are awesome.

#Issues, Questions, Wana Help?
We take Pull Requests! See http://codeforhamptonroads.org for getting involved, and http://codeforamerica.org if outside Hampton Roads, Virginia. Use github's issues if you see a problem or have a feature request. You can contact the maintainer Bret Fisher at bret@codeforamerica.org or @BretFisher.
